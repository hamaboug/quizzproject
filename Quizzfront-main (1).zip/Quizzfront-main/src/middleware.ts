import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";
import { jwtVerify } from "jose"; // Use jose instead of jsonwebtoken


export async function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl;
  console.log("Middleware running for:", pathname); // Debugging

  const secret=process.env.JWT_SECRET;

  

  if (
    pathname.startsWith("/login") ||
    pathname.startsWith("/signup") ||
    pathname.startsWith("/_next") ||
    pathname.startsWith("/favicon.ico")
  ) {
    return NextResponse.next();
  }
  const token = req.cookies.get("token")?.value;
  console.log("Token found in cookies:", token);

  if (!token) {
    console.log("No token, redirecting to /login");
    return NextResponse.redirect(new URL("/login", req.url));
  }

  try {
    const { payload } = await jwtVerify(token, new TextEncoder().encode(secret));
    console.log("Decoded token:", payload);

    const userRole = (payload as { role?: string }).role;
    if (pathname.startsWith("/admin") && userRole !== "admin") {
      console.log("Unauthorized user, redirecting to /unauthorized");
      return NextResponse.redirect(new URL("/unauthorized", req.url));
    }

    console.log("Token valid, allowing access");
    return NextResponse.next();
  } catch (error) {
    console.error("Error decoding token:", error);
    return NextResponse.redirect(new URL("/login", req.url));
  }
}


export const config = {
  matcher: ["/:path*"], // Add other protected routes here
};