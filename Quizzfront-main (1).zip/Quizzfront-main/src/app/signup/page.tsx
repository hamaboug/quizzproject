"use client";

import { Lock, Mail } from "lucide-react"
import { getGradient, theme } from "../theme"

import Image from "next/image";
import Link from "next/link";
import { motion } from "framer-motion";
import { useRouter } from "next/navigation";
import { useState } from "react";

export default function Signup() {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [error, setError] = useState("")
  const [success, setSuccess] = useState("")
  const router = useRouter()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!email.endsWith("@teamwillgroup.com")) {
      setError("You must register with a Teamwill Email Address")
      return
    }

    const userData = {
      email,
      password,
    }

    try {
      const response = await fetch("http://localhost:42069/users/register", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(userData),
      })

      if (response.ok) {
        setSuccess("Registration successful! You can now proceed to login.")
        setError("")
        setEmail("")
        setPassword("")
        router.push("/login")
      } else {
        const data = await response.json()
        setError(data.message || "Sign up failed")
        setSuccess("")
      }
    } catch (error) {
      console.error("Error during sign up:", error)
      setError("An error occurred during sign up")
      setSuccess("")
    }

    try {
      const response = await fetch("http://localhost:42069/users/register", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          username: name,
          email: email,
          password: password,
        }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Registration failed");
      }

      const data = await response.json();
      console.log("Registration successful:", data);

      router.push("/login");
    } catch (error) {
      console.error("Error during registration:", error);
      setError(error.message || "An error occurred during registration.");
    }
  };
  
  return (
    <div className="flex min-h-screen">
      <div
        className="hidden lg:flex lg:w-1/2 flex-col items-center justify-center p-12 text-white"
        style={{ background: getGradient(theme.colors.primary) }}
      >
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          <h1 className="text-5xl font-bold mb-6 text-center">Join TeamWill Quiz</h1>
          <p className="text-xl text-center max-w-md">
            Create an account to start your journey of knowledge and skill improvement!
          </p>
        </motion.div>
      </div>
      <div className="w-full lg:w-1/2 flex items-center justify-center p-8 bg-white">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="w-full max-w-md"
        >
          <div className="flex justify-center mb-8">
            <Image
              src="/images/logo-teamwill.png"
              alt="TeamWill Quiz"
              width={400}
              height={350}
              className="object-contain"
              priority
            />
          </div>
          <h2 className="text-2xl font-semibold text-gray-800 mb-2 text-center">Sign Up</h2>
          <p className="text-gray-600 mb-8 text-center">Create your TeamWill Quiz account</p>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="relative">
              <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Enter your TeamWill email"
                className="w-full pl-10 pr-3 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-gray-800"
                required
              />
            </div>
            <div className="relative">
              <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Create a password"
                className="w-full pl-10 pr-3 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-gray-800"
                required
              />
            </div>
            <button
              type="submit"
              className="w-full py-3 px-4 border border-transparent rounded-lg shadow-sm text-sm font-medium text-white focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-all duration-300 transform hover:-translate-y-1 hover:shadow-md"
              style={{ background: getGradient(theme.colors.primary) }}
            >
              Sign Up
            </button>
          </form>
          {error && (
            <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="mt-4 text-red-500 text-center">
              {error}
            </motion.p>
          )}
          {success && (
            <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="mt-4 text-green-500 text-center">
              {success}
            </motion.p>
          )}
          <p className="mt-6 text-center text-gray-600">
            Already have an account?{" "}
            <Link href="/login" className="text-blue-500 hover:text-blue-600 font-medium">
              Sign in
            </Link>
          </p>
        </motion.div>
      </div>
    </div>
  )
}