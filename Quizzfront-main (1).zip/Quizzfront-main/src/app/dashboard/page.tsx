import { DashboardContent } from "../components/DashboardContent"
import { Navbar } from "../components/Navbar"
import { Sidebar } from "../components/Sidebar"
import { theme } from "../theme"

export default function Dashboard() {
  const userName = "John Doe"

  return (
    <div className="min-h-screen" style={{ backgroundColor: theme.colors.background }}>
      <Navbar  />
      <div className="flex">
        <Sidebar />
        <DashboardContent />
      </div>
    </div>
  )
}

