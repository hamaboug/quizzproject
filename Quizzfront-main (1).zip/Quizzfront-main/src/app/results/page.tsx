"use client"

import { useState, useEffect } from "react"
import { getGradient, theme } from "../theme"
import { Navbar } from "../components/Navbar"
import { Sidebar } from "../components/Sidebar"
import { motion } from "framer-motion"
import { fetchWithAuth } from "../lib/auth"
import Cookies from "js-cookie"
import { jwtDecode } from "jwt-decode"
import { useRouter } from "next/navigation"
import { log } from "console"

interface DecodedToken {
  id: number
  role: string
  sub: string
  iat: number
}

export default function Results() {
  const [results, setResults] = useState<
    { id: number; quizTitle: string; score: number; timeTaken: number }[]
  >([])
  const [error, setError] = useState<string | null>(null)
  const [loading, setLoading] = useState<boolean>(true)
  const router = useRouter()

  useEffect(() => {
    const fetchResults = async () => {
      try {
        const token = Cookies.get("token")
        if (!token) {
          router.push("/login")
          return
        }

        const decodedToken = jwtDecode<DecodedToken>(token)
        console.log("Decoded Token:", decodedToken) // Log the decoded token to inspect its structure
        const userId = decodedToken.id
        if (!userId) {
          throw new Error("User ID not found in token")
        }
        console.log("userId", userId)

        const response = await fetchWithAuth(`http://localhost:42069/results/user/${userId}`)
        if (!response.ok) throw new Error("Failed to fetch results")

          const data = await response.json()
          const formattedResults = data.map((result: any) => ({
            id: result.id,
            userId: result.user.email,
            quizId: result.quiz.id,
            quizTitle: result.quiz.title,
            score: result.score,
            timeTaken: result.timeInMinutes * 60, // Convert minutes to seconds
          }))
          setResults(formattedResults)
        console.log("results", formattedResults);

      } catch (error) {
        console.error("Error fetching results:", error)
        setError("Failed to fetch results")
      } finally {
        setLoading(false)
      }
    }

    fetchResults()
  }, [router])

  const getScoreColor = (score: number) => {
    if (score >= 75) return "text-green-500"
    if (score >= 60) return "text-orange-500"
    return "text-red-500"
  }

  function formatTime(timeInSeconds: number): string {
    // Calculate minutes and seconds
    const minutes = Math.floor(timeInSeconds / 60);
    const seconds = Math.floor(timeInSeconds % 60);
  
    // Format minutes and seconds to be two digits each
    const formattedMinutes = minutes.toString().padStart(2, '0');
    const formattedSeconds = seconds.toString().padStart(2, '0');
  
    return `${formattedMinutes}:${formattedSeconds}`;
  }

  if (loading) {
    return <div>Loading...</div>
  }

  return (
    <div className="min-h-screen" style={{ backgroundColor: theme.colors.background }}>
      <Navbar />
      <div className="flex">
        <Sidebar />
        <main className="flex-1 p-8">
          <motion.h1
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="text-4xl font-bold mb-8 text-gray-800"
          >
            Your Quiz Results
          </motion.h1>
          {error && <p className="text-red-500">{error}</p>}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="bg-white rounded-lg shadow-lg overflow-hidden"
          >
            <table className="w-full border-collapse">
              <thead>
                <tr style={{ background: getGradient(theme.colors.primary) }}>
                  <th className="p-4 text-left text-white font-semibold">Quiz</th>
                  <th className="p-4 text-left text-white font-semibold">Score</th>
                  <th className="p-4 text-left text-white font-semibold">Time Taken (MM:SS)</th>
                </tr>
              </thead>
              <tbody>
                {results.map((result) => (
                  <tr key={result.id}>
                    <td className="p-4">{result.quizTitle}</td>
                    <td className={`p-4 ${getScoreColor(result.score)}`}>{result.score.toFixed(2)}%</td>
                    <td className="p-4">{formatTime(result.timeTaken) }</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </motion.div>
        </main>
      </div>
    </div>
  )
}