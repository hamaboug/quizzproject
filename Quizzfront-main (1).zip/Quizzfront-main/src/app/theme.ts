// Define the theme object
const theme = {
    colors: {
      primary: "#95a657",
      secondary: "#5f5f5f",
      background: "#fefefd",
      text: "#1F2937",
      accent: "#b8bda6",
      muted: "#f3f9dc",
    },
    fontFamily: {
      sans: "'Montserrat', sans-serif",
    },
    borderRadius: {
      sm: "0.125rem",
      default: "0.25rem",
      md: "0.375rem",
      lg: "0.5rem",
      xl: "0.75rem",
      full: "9999px",
    },
  }
  
  // Export the theme type
  export type Theme = typeof theme
  
  // Utility function to generate gradients
  export const getGradient = (color: string, intensity = 0.2): string => {
    return `linear-gradient(135deg, ${color}, ${adjustColor(color, intensity)})`
  }
  
  // Utility function to adjust colors
  export const adjustColor = (color: string, amount: number): string => {
    const clamp = (num: number): number => Math.min(Math.max(num, 0), 255)
    const hex = color.replace("#", "")
    const r = Number.parseInt(hex.slice(0, 2), 16)
    const g = Number.parseInt(hex.slice(2, 4), 16)
    const b = Number.parseInt(hex.slice(4, 6), 16)
  
    const adjustedR = clamp(r + Math.round(r * amount))
    const adjustedG = clamp(g + Math.round(g * amount))
    const adjustedB = clamp(b + Math.round(b * amount))
  
    return `#${adjustedR.toString(16).padStart(2, "0")}${adjustedG.toString(16).padStart(2, "0")}${adjustedB.toString(16).padStart(2, "0")}`
  }
  
  // Export the theme object
  export { theme }
  
  