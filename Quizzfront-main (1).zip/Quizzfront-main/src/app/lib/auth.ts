import Cookies from "js-cookie";

export const fetchWithAuth = async (url: string, options: RequestInit = {}) => {
  const token = Cookies.get("token"); // Retrieve token from cookies

  if (!token) {
    throw new Error("No token found");
  }

  const headers = {
    ...options.headers,
    "Content-Type": "application/json",
    "Authorization": `Bearer ${token}`,
  };

  const response = await fetch(url, {
    ...options,
    headers,
  });

  if (!response.ok) {
    const errorData = await response.json();
    throw new Error(errorData.message || "Request failed");
  }

  return response;
};
