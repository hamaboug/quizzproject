"use client"

import { Lock, Mail } from "lucide-react"
import { getGradient, theme } from "../theme"
import Cookies from 'js-cookie';
import { jwtVerify } from "jose"; // Use jose instead of jsonwebtoken
import {jwtDecode} from "jwt-decode"

import Image from "next/image"
import Link from "next/link"
import { motion } from "framer-motion"
import { useRouter } from "next/navigation"
import { useState } from "react"

export default function Login() {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [error, setError] = useState("")
  const router = useRouter()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    const userData = {
      email,
      password,
    }

    try {
      const response = await fetch("http://localhost:42069/users/login", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(userData),
      })

      if (response.ok) {
        const token = await response.text(); // Get the plain text JWT token
        
        // Store the token in a cookie
        Cookies.set('token', token, { expires: 1, path: '/', secure: true, sameSite: 'strict' });

        try {
         

          
          // Decode the JWT to extract the role
          const decodedToken = jwtDecode<{ role?: string }>(token)

          // Extract the role from the decoded token
          const userRole = decodedToken.role

          // Check the role and redirect accordingly
          if (userRole === 'admin') {
            router.push("/admin");
          } else {
            router.push("/dashboard");
          }
        } catch (error) {
          console.error("Error decoding token:", error);
          setError("Invalid token received");
        }
      } else {
        const data = await response.json();
        setError(data.message || "Login failed");
      }
    } catch (error) {
      console.error("Error during login:", error)
      setError("An error occurred during login")
    }
  }

  return (
    <div className="flex min-h-screen">
      <div
        className="hidden lg:flex lg:w-1/2 flex-col items-center justify-center p-12 text-white"
        style={{ background: getGradient(theme.colors.primary) }}
      >
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          <h1 className="text-5xl font-bold mb-6 text-center">Welcome Back to TeamWill Quiz</h1>
          <p className="text-xl text-center max-w-md mx-auto">
            Test your knowledge, challenge your skills, and grow with our interactive quizzes!
          </p>
        </motion.div>
      </div>
      <div className="w-full lg:w-1/2 flex items-center justify-center p-8 bg-white">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="w-full max-w-md"
        >
          <div className="flex justify-center mb-8">
            <Image
              src="/images/logo-teamwill.png"
              alt="TeamWill Quiz"
              width={400}
              height={350}
              className="object-contain"
              priority
            />
          </div>
          <p className="text-gray-600 mb-8 text-center">Please use your TeamWill email to continue.</p>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="relative">
              <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Enter your TeamWill email"
                className="w-full pl-10 pr-3 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-gray-800"
                required
              />
            </div>
            <div className="relative">
              <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Enter your password"
                className="w-full pl-10 pr-3 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-gray-800"
                required
              />
            </div>
            <button
              type="submit"
              className="w-full py-3 px-4 border border-transparent rounded-lg shadow-sm text-sm font-medium text-white focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-all duration-300 transform hover:-translate-y-1 hover:shadow-md"
              style={{ background: getGradient(theme.colors.primary) }}
            >
              Log In
            </button>
          </form>
          {error && (
            <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="mt-4 text-red-500 text-center">
              {error}
            </motion.p>
          )}
          <p className="mt-6 text-center text-gray-600">
            Don&apos;t have an account?{" "}
            <Link href="/signup" className="text-blue-500 hover:text-blue-600 font-medium">
              Sign up
            </Link>
          </p>
        </motion.div>
      </div>
    </div>
  )
}