"use client"

import { BarChart, ClipboardList, Home, LogOut, PlusCircle } from "lucide-react"

import Link from "next/link"
import { motion } from "framer-motion"
import { useRouter } from "next/navigation"

import Cookies from "js-cookie"

export function Sidebar({ isAdmin = false }: { isAdmin?: boolean }) {
  const router = useRouter()

  const handleLogout = () => {
    console.log("Logging out...")
    sessionStorage.clear()
    localStorage.clear()
    Cookies.remove("token")
    router.replace("/login")
  }

  return (
    <motion.aside
      initial={{ opacity: 0, x: -50 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.5 }}
      className="bg-white w-64 min-h-screen p-4 shadow-lg flex flex-col"
    >
      <nav className="flex-grow">
        <ul className="space-y-2">
          {isAdmin ? (
            <>
              <SidebarItem href="/admin" icon={<BarChart size={20} />}>
                Admin Dashboard
              </SidebarItem>
              <SidebarItem href="/admin/create-quiz" icon={<PlusCircle size={20} />}>
                Create Quiz
              </SidebarItem>
              <SidebarItem href="/admin/user-results" icon={<ClipboardList size={20} />}>
                User Results
              </SidebarItem>
            </>
          ) : (
            <>
              <SidebarItem href="/dashboard" icon={<Home size={20} />}>
                Dashboard
              </SidebarItem>
              <SidebarItem href="/results" icon={<ClipboardList size={20} />}>
                Results
              </SidebarItem>
            </>
          )}
        </ul>
      </nav>
      <div className="pt-4 mt-auto border-t border-gray-200">
        <button
          onClick={handleLogout}
          className="flex items-center w-full p-2 rounded-lg text-gray-600 hover:bg-gray-100 transition duration-300"
        >
          <LogOut size={20} className="mr-2" />
          Logout
        </button>
      </div>
    </motion.aside>
  )
}

function SidebarItem({ href, icon, children }: { href: string; icon: React.ReactNode; children: React.ReactNode }) {
  return (
    <li>
      <Link
        href={href}
        className="flex items-center p-2 rounded-lg text-gray-600 hover:bg-gray-100 transition duration-300"
      >
        {icon}
        <span className="ml-2">{children}</span>
      </Link>
    </li>
  )
}

