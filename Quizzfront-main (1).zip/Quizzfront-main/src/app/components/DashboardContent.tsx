"use client"

import { getGradient, theme } from "../theme"
import { useEffect, useState } from "react"

import { ArrowRight } from "lucide-react"
import Link from "next/link"
import { motion } from "framer-motion"
import { fetchWithAuth } from "../lib/auth"

interface Quiz {
  description: string
  id: number
  title: string
}

export function DashboardContent() {
  const [quizzes, setQuizzes] = useState<Quiz[]>([])

  useEffect(() => {
    const fetchQuizzes = async () => {
      try {
        const response = await fetchWithAuth("http://localhost:42069/quizzes")
        const data = await response.json()
        setQuizzes(data)
      } catch (error) {
        console.error("Error fetching quizzes:", error)
      }
    }

    fetchQuizzes()
  }, [])

  return (
    <main className="flex-1 p-8">
      <motion.h1
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="text-4xl font-bold mb-8 text-gray-800"
      >
        Available Quizzes
      </motion.h1>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {quizzes.map((quiz, index) => (
          <motion.div
            key={quiz.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: index * 0.1 }}
          >
            <Link href={`/quiz/${quiz.id}`}>
              <div
                className="p-6 bg-white rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1 cursor-pointer overflow-hidden relative"
                style={{ borderLeft: `4px solid ` }}
              >
                <div className="flex items-center mb-4">
                  <h2 className="text-xl font-semibold text-gray-800">{quiz.title}</h2>
                </div>
                <div className="text-gray-600 mb-4">{quiz.description}</div>
                <div className="flex items-center text-sm font-medium text-blue-500">
                  Start Quiz
                  <ArrowRight size={16} className="ml-1" />
                </div>
                <div
                  className="absolute inset-0 bg-gradient-to-r opacity-10"
                  style={{ background: getGradient(theme.colors.primary) }}
                />
              </div>
            </Link>
          </motion.div>
        ))}
      </div>
    </main>
  )
}
