"use client"; // Mark this as a Client Component

import { getGradient, theme } from "../theme";

import { User } from "lucide-react"
import { motion } from "framer-motion"
import {jwtDecode} from "jwt-decode"
import Cookies from 'js-cookie';



export function Navbar() {

        const token = Cookies.get('token')
        let userEmail = ''
        if (token) {
            const decodedToken = jwtDecode<{ sub?: string }>(token)
            userEmail = decodedToken.sub || ''
        }


  return (
    <motion.nav
      initial={{ opacity: 0, y: -50 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="text-white p-4 shadow-lg"
      style={{
        background: getGradient(theme.colors.primary),
        fontFamily: theme.fontFamily.sans,
      }}
    >
      <div className="container mx-auto flex justify-between items-center">
        <div className="text-2xl font-bold tracking-tight">Teamwill Quiz</div>
        <div className="flex items-center space-x-2 bg-white bg-opacity-20 rounded-full px-4 py-2">
          <User size={20} />
          <div className="text-sm font-medium">{userEmail}</div>
        </div>
      </div>
    </motion.nav>
  );
}