"use client"
import React, { useEffect, useState } from 'react';
import { useRouter, useParams } from 'next/navigation';
import { motion } from 'framer-motion';
import { Navbar } from "../../components/Navbar";
import { getGradient, theme } from "../../theme";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { fetchWithAuth } from '@/app/lib/auth';
import Cookies from 'js-cookie';
import { jwtDecode } from 'jwt-decode';
import { start } from 'repl';

interface DecodedToken {
  id: number
  role: string
  sub: string
  iat: number
}

interface Option {
  id: number;
  text: string;
  correct: boolean;
}

interface Question {
  id: number;
  enonce: string;
  options?: Option[];
  expectedAnswer?: string;
}

interface QuizData {
  id: number;
  title: string;
  description: string;
  questions: Question[];
}

export default function Quiz() {
  const [quizData, setQuizData] = useState<QuizData | null>(null);
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [userAnswers, setUserAnswers] = useState<any[]>([]);
  const [selectedOptions, setSelectedOptions] = useState<number[]>([]);
  const [textAnswer, setTextAnswer] = useState<string>('');
  const [quizCompleted, setQuizCompleted] = useState(false);
  const [startTime, setStartTime] = useState<number | null>(null);
  const [endTime, setEndTime] = useState<number | null>(null);
  const [score, setScore] = useState<number | null>(null);
  const router = useRouter();
  const params = useParams();
  const token = Cookies.get("token");
  const decodedToken = token ? jwtDecode<DecodedToken>(token) : null;
  const userId = decodedToken ? decodedToken.id : null;

  useEffect(() => {

    const fetchQuiz = async () => {
      try {

        

        const response = await fetchWithAuth(`http://localhost:42069/quizzes/${params.id}`);
        const data = await response.json();
        setQuizData(data);
        setStartTime(Date.now());
        console.log("start"+startTime);
        
      } catch (error) {
        console.error('Error fetching quiz:', error);
      }
    };
    fetchQuiz();
  }, [params]);

  const handleOptionSelect = (index: number) => {
    if (selectedOptions.includes(index)) {
      setSelectedOptions(selectedOptions.filter(option => option !== index));
    } else {
      setSelectedOptions([...selectedOptions, index]);
    }
  };

  const handleTextAnswerChange = (text: string) => {
    setTextAnswer(text);
  };

  const handleNextQuestion = () => {
    console.log(startTime);
    
    if (quizData) {
      const question = quizData.questions[currentQuestion];
      const answerEntry = question.options
        ? {
            type: "multiple_choice",
            questionId: question.id,
            userId,
            selectedOptionIds: selectedOptions.map(index => question.options![index].id),
          }
        : {
            type: "text",
            questionId: question.id,
            userId,
            answerText: textAnswer,
          };

      setUserAnswers([...userAnswers, answerEntry]);
      setSelectedOptions([]);
      setTextAnswer('');

      if (currentQuestion < quizData.questions.length - 1) {
        setCurrentQuestion(currentQuestion + 1);
      } else {
        setEndTime(Date.now());
        console.log("end"+endTime);
        
        setQuizCompleted(true);
        submitResults([...userAnswers, answerEntry]);
      }
    }
  };

  const submitResults = async (answers: any[]) => {
    if (!quizData) return;

    // Ensure startTime is set properly before calling this function
    if (!startTime) {
      console.error("Error: startTime is not set!");
      return;
    }
  
    const end = Date.now(); // Capture current time as endTime when submitting
    const start = startTime; // Use the existing startTime
    const timeInMinutes = Math.max(0, (end - start) / 60000); // Prevent negative values
  
    console.log("📌 startTime:", start);
    console.log("📌 endTime:", end);
    console.log("⏳ Time Difference (ms):", end - start);
    console.log("⏳ Time Difference (minutes):", timeInMinutes);
  
    const resultPayload = {
      userId,
      quizId: quizData.id,
      answers,
      timeInMinutes,
    };

    try {
      const response = await fetchWithAuth("http://localhost:42069/results/submit", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(resultPayload),
      });
      const data = await response.json();
      setScore(data.score);
      console.log("Submission Success:", data);
    } catch (error) {
      console.error("Error submitting quiz results:", error);
    }
  };

  if (!quizData) {
    return <div>Loading...</div>;
  }

  if (quizCompleted) {
    return (
      <div className="min-h-screen bg-[rgb(var(--color-background))]">
        <Navbar/>
        <div className="flex items-center justify-center p-8">
          <motion.div className="bg-white p-8 rounded-lg shadow-lg max-w-2xl w-full">
            <h1 className="text-3xl font-bold mb-4">Quiz Completed</h1>
            {score !== null && <p className="text-xl font-semibold">Your Score: {score}%</p>}
            <button
              onClick={() => router.push('/dashboard')}
              className="w-full px-4 py-2 text-white rounded-lg transition-all"
              style={{ background: getGradient(theme.colors.primary) }}
            >
              Back to Dashboard
            </button>
          </motion.div>
        </div>
      </div>
    );
  }

  const question = quizData.questions[currentQuestion];
  return (
    <div className="min-h-screen bg-[rgb(var(--color-background))]">
      <Navbar />
      <div className="flex items-center justify-center p-8">
        <motion.div className="bg-white p-8 rounded-lg shadow-lg max-w-2xl w-full">
          <h1 className="text-2xl font-bold mb-6 text-gray-800">{quizData.title}</h1>
          <p className="text-xl mb-4 text-gray-700">{question.enonce}</p>
          <div className="space-y-3">
            {question.options ? (
              question.options.map((option, index) => (
                <button
                  key={option.id}
                  onClick={() => handleOptionSelect(index)}
                  className={`w-full p-4 text-left border rounded-lg ${selectedOptions.includes(index) ? 'bg-gray-200' : ''}`}
                >
                  {option.text}
                </button>
              ))
            ) : (
              <Textarea
                placeholder="Type your answer here..."
                value={textAnswer}
                onChange={(e) => handleTextAnswerChange(e.target.value)}
                className="w-full p-4 border rounded-lg"
              />
            )}
          </div>
          <Button onClick={handleNextQuestion} className="mt-4" disabled={question.options ? selectedOptions.length === 0 : textAnswer.trim() === ''}>
            Next Question
          </Button>
        </motion.div>
      </div>
    </div>
  );
}
