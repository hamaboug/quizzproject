import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

import Link from "next/link"

export default function AdminDashboard() {
  return (
    <div>
      <h1 className="text-3xl font-bold mb-6">Admin Dashboard</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Link href="/admin/create-quiz">
          <Card className="hover:shadow-lg transition-shadow">
            <CardHeader>
              <CardTitle>Create Quiz</CardTitle>
            </CardHeader>
            <CardContent>
              <div>Create a new quiz for users to take.</div>
            </CardContent>
          </Card>
        </Link>
        <Link href="/admin/user-results">
          <Card className="hover:shadow-lg transition-shadow">
            <CardHeader>
              <CardTitle>User Results</CardTitle>
            </CardHeader>
            <CardContent>
              <div>View and analyze user quiz results.</div>
            </CardContent>
          </Card>
        </Link>
      </div>
    </div>
  )
}

