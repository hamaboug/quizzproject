"use client"
import React, { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Trash2 } from "lucide-react"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { fetchWithAuth } from '@/app/lib/auth';

interface Option {
  text: string;
  isCorrect: boolean;
}

interface Question {
  type: 'multiple-choice' | 'written';
  question: string;
  options?: Option[];
  expectedAnswer?: string;
}

const CreateQuizPage = () => {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [questions, setQuestions] = useState<Question[]>([]);
  const router = useRouter();

  const addQuestion = () => {
    setQuestions([...questions, { type: 'multiple-choice', question: '', options: [{ text: '', isCorrect: false }] }]);
  };

  const updateQuestion = (index: number, key: string, value: any) => {
    const newQuestions = [...questions];
    newQuestions[index] = { ...newQuestions[index], [key]: value };
    setQuestions(newQuestions);
  };

  const updateOption = (questionIndex: number, optionIndex: number, value: string) => {
    const newQuestions = [...questions];
    if (newQuestions[questionIndex].options) {
      newQuestions[questionIndex].options![optionIndex].text = value;
    }
    setQuestions(newQuestions);
  };

  const addOption = (questionIndex: number) => {
    const newQuestions = [...questions];
    if (newQuestions[questionIndex].options) {
      newQuestions[questionIndex].options!.push({ text: '', isCorrect: false });
    }
    setQuestions(newQuestions);
  };

  const removeQuestion = (index: number) => {
    const newQuestions = questions.filter((_, i) => i !== index);
    setQuestions(newQuestions);
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();

    const multipleChoiceQuestions = questions
      .filter(q => q.type === 'multiple-choice')
      .map(q => ({
        enonce: q.question,
        options: q.options,
      }));

    const textQuestions = questions
      .filter(q => q.type === 'written')
      .map(q => ({
        enonce: q.question,
        expectedAnswer: q.expectedAnswer,
      }));

    const quiz = {
      title,
      description,
      multipleChoiceQuestions,
      textQuestions,
    };

    try {
      const response = await fetchWithAuth('http://localhost:42069/quizzes', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(quiz),
      });

      if (!response.ok) {
        throw new Error('Failed to create quiz');
      }

      const data = await response.json();
      console.log('Quiz created successfully:', data);
      router.push('/admin');
    } catch (error) {
      console.error('Error creating quiz:', error);
    }
  };

  return (
    <div className="max-w-4xl mx-auto">
      <h1 className="text-3xl font-bold mb-6">Create Quiz</h1>
      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <Label htmlFor="title">Quiz Title</Label>
          <Input
            id="title"
            value={title}
            onChange={(e: React.ChangeEvent<HTMLInputElement>) => setTitle(e.target.value)}
            required
          />
        </div>
        <div>
          <Label htmlFor="description">Quiz Description</Label>
          <Textarea
            id="description"
            value={description}
            onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setDescription(e.target.value)}
          />
        </div>
        {questions.map((question, questionIndex) => (
          <div key={questionIndex} className="border p-4 rounded-md">
            <div className="mb-4">
              <Label htmlFor={`question-${questionIndex}`}>Question {questionIndex + 1}</Label>
              <Textarea
                id={`question-${questionIndex}`}
                value={question.question}
                onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) =>
                  updateQuestion(questionIndex, 'question', e.target.value)
                }
                required
              />
            </div>
            {question.type === 'multiple-choice' && (
              <>
                {question.options?.map((option, optionIndex) => (
                  <div key={optionIndex} className="flex items-center space-x-2 mb-2">
                    <Input
                      value={option.text}
                      onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                        updateOption(questionIndex, optionIndex, e.target.value)
                      }
                      required
                      className="flex-grow"
                    />
                    <input
                      type="checkbox"
                      checked={option.isCorrect}
                      onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                        updateQuestion(questionIndex, 'options', question.options?.map((opt, idx) =>
                          idx === optionIndex ? { ...opt, isCorrect: e.target.checked } : opt
                        ))
                      }
                    />
                  </div>
                ))}
                <Button type="button" onClick={() => addOption(questionIndex)}>
                  Add Option
                </Button>
              </>
            )}
            {question.type === 'written' && (
              <div className="mt-4">
                <Label htmlFor={`expected-answer-${questionIndex}`}>Expected Answer</Label>
                <Textarea
                  id={`expected-answer-${questionIndex}`}
                  value={question.expectedAnswer || ''}
                  onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) =>
                    updateQuestion(questionIndex, 'expectedAnswer', e.target.value)
                  }
                  required
                />
              </div>
            )}
            <div className="mt-2">
              <Label>Question Type</Label>
              <RadioGroup
                value={question.type}
                onValueChange={(value: 'multiple-choice' | 'written') => updateQuestion(questionIndex, 'type', value)}
                className="flex space-x-4"
              >
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="multiple-choice" id={`question-${questionIndex}-type-multiple`} />
                  <Label htmlFor={`question-${questionIndex}-type-multiple`}>Multiple Choice</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="written" id={`question-${questionIndex}-type-written`} />
                  <Label htmlFor={`question-${questionIndex}-type-written`}>Written Answer</Label>
                </div>
              </RadioGroup>
            </div>
            {questions.length > 1 && (
              <Button
                type="button"
                onClick={() => removeQuestion(questionIndex)}
                className="mt-2"
                variant="destructive"
              >
                <Trash2 className="mr-2 h-4 w-4" /> Remove Question
              </Button>
            )}
          </div>
        ))}
        <Button type="button" onClick={addQuestion}>
          Add Question
        </Button>
        <Button type="submit" className="mt-4 ml-4">
          Create Quiz
        </Button>
      </form>
    </div>
  );
};

export default CreateQuizPage;
