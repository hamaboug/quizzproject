import { Navbar } from "../components/Navbar"
import { Sidebar } from "../components/Sidebar"

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen bg-gray-100">
      <Navbar  />
      <div className="flex">
      <Sidebar isAdmin={true} />
        <main className="flex-1 p-8">{children}</main>
      </div>
    </div>
  )
}

