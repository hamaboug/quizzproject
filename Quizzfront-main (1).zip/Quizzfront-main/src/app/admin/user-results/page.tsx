"use client"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { useEffect, useState } from "react"
import { fetchWithAuth } from "../../lib/auth"

interface Result {
  id: number
  userId: string
  quizId: number
  quizTitle: string
  score: number
  timeTaken: number
}

export default function UserResults() {
  const [results, setResults] = useState<Result[]>([])
  const [error, setError] = useState<string | null>(null)
  const [loading, setLoading] = useState<boolean>(true)

  useEffect(() => {
    const fetchResults = async () => {
      try {
        const res = await fetchWithAuth("http://localhost:42069/results")
        const data = await res.json()
        const formattedResults = data.map((result: any) => ({
          id: result.id,
          userId: result.user.email,
          quizId: result.quiz.id,
          quizTitle: result.quiz.title,
          score: result.score,
          timeTaken: result.timeInMinutes * 60, // Convert minutes to seconds
        }))
        setResults(formattedResults)
      } catch (error) {
        console.error("Error fetching results:", error)
        setError("Failed to fetch results")
      } finally {
        setLoading(false)
      }
    }

    fetchResults()
  }, [])

  const formatTime = (seconds: number) => {
    const minutes = Math.floor(seconds / 60)
    const remainingSeconds = seconds % 60
    return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`
  }

  if (loading) {
    return <div>Loading...</div>
  }

  return (
    <div>
      <h1 className="text-3xl font-bold mb-6">User Results</h1>
      {error && <div className="text-red-500">{error}</div>}
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>User</TableHead>
            <TableHead>Quiz</TableHead>
            <TableHead>Score</TableHead>
            <TableHead>Time Taken </TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {results.map((result) => (
            <TableRow key={result.id}>
              <TableCell>{result.userId}</TableCell>
              <TableCell>{result.quizTitle}</TableCell>
              <TableCell>{result.score}%</TableCell>
              <TableCell>{formatTime(result.timeTaken)}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  )
}