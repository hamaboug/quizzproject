package com.quiz.back.services;

import com.quiz.back.models.TextAnswer;
import com.quiz.back.repositories.TextAnswerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class TextAnswerService {
    @Autowired
    private TextAnswerRepository textAnswerRepository;

    public List<TextAnswer> findAll() {
        return textAnswerRepository.findAll();
    }

    public Optional<TextAnswer> findById(Long id) {
        return textAnswerRepository.findById(id);
    }

    public TextAnswer save(TextAnswer answer) {
        return textAnswerRepository.save(answer);
    }

    public void deleteById(Long id) {
        textAnswerRepository.deleteById(id);
    }
}