package com.quiz.back.models;

import lombok.Data;

@Data
public class OptionDTO {
    private String text;
    private boolean isCorrect;


    public boolean isCorrect() {
        return this.isCorrect;
    }

    public void setIsCorrect(boolean isCorrect) {
        this.isCorrect = isCorrect;
    }
}
