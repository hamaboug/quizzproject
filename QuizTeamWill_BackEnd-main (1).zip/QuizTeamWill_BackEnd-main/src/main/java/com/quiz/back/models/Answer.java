package com.quiz.back.models;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
@Table(name="answer")
@Inheritance(strategy = InheritanceType.SINGLE_TABLE) // All subclasses share the same table
@DiscriminatorColumn(name = "answer_type", discriminatorType = DiscriminatorType.STRING) // Discriminator column
public class Answer {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "question_id", nullable = false)
    @JsonManagedReference
    private Question question;

    @ManyToOne
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @ManyToOne
    @JoinColumn(name = "result_id", nullable = false)
    @JsonBackReference
    private Result result;

}
