package com.quiz.back.repositories;

import com.quiz.back.models.TextAnswer;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface TextAnswerRepository extends JpaRepository<TextAnswer, Long> {
}