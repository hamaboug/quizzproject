package com.quiz.back.models;

import java.util.List;

import lombok.Data;


@Data
public class MultipleChoiceQuestionDTO {
    private String enonce;
    private List<OptionDTO> options;

}
