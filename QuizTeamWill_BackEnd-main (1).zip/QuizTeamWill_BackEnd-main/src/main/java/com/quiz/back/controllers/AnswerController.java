package com.quiz.back.controllers;

import com.quiz.back.models.Answer;
import com.quiz.back.services.AnswerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/answers")
public class AnswerController {

    @Autowired
    private AnswerService answerService;

    @GetMapping
    public List<Answer> findAll() {
        return answerService.findAll();
    }

    @GetMapping("/{id}")
    public Optional<Answer> findById(@PathVariable Long id) {
        return answerService.findById(id);
    }

    @PostMapping
    public Answer save(@RequestBody Answer Answer) {
        return answerService.save(Answer);
    }

    @DeleteMapping("/{id}")
    public void deleteById(@PathVariable Long id) {
        answerService.deleteById(id);
    }
}