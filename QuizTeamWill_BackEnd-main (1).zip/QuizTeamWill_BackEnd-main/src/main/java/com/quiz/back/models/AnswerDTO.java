package com.quiz.back.models;

import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;

import lombok.Data;

@Data
@JsonTypeInfo(
    use = JsonTypeInfo.Id.NAME,
    include = JsonTypeInfo.As.PROPERTY,
    property = "type"
)
@JsonSubTypes({
    @JsonSubTypes.Type(value = MultipleChoiceAnswerDTO.class, name = "multiple_choice"),
    @JsonSubTypes.Type(value = TextAnswerDTO.class, name = "text")
})
public  class AnswerDTO {    
    public static final String MULTIPLE_CHOICE = "multiple_choice";
    public static final String TEXT = "text";
    private Long id;
    private Long questionId;
    private Long userId;
    private String type;

    
}
