package com.quiz.back.models;

import lombok.Data;

@Data
public class TextQuestionDTO {
    private String enonce;
    private String expectedAnswer;

}
