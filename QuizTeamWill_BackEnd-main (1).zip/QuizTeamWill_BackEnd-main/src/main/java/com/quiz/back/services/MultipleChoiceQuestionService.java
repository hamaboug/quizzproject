package com.quiz.back.services;

import com.quiz.back.models.MultipleChoiceQuestion;
import com.quiz.back.repositories.MultipleChoiceQuestionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class MultipleChoiceQuestionService {

    @Autowired
    private MultipleChoiceQuestionRepository multipleChoiceQuestionRepository;

    public List<MultipleChoiceQuestion> findAll() {
        return multipleChoiceQuestionRepository.findAll();
    }

    public Optional<MultipleChoiceQuestion> findById(Long id) {
        return multipleChoiceQuestionRepository.findById(id);
    }

    public MultipleChoiceQuestion save(MultipleChoiceQuestion multipleChoiceQuestion) {
        return multipleChoiceQuestionRepository.save(multipleChoiceQuestion);
    }

    public void deleteById(Long id) {
        multipleChoiceQuestionRepository.deleteById(id);
    }
}