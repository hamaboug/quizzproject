package com.quiz.back.controllers;

import com.quiz.back.models.TextAnswer;
import com.quiz.back.services.TextAnswerService;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/text-answers")
public class TextAnswerController {
    @Autowired
    private TextAnswerService textAnswerService;

    @GetMapping
    public List<TextAnswer> findAll() {
        return textAnswerService.findAll();
    }

    @GetMapping("/{id}")
    public Optional<TextAnswer> findById(@PathVariable Long id) {
        return textAnswerService.findById(id);
    }

    @PostMapping
    public TextAnswer save(@RequestBody TextAnswer answer) {
        return textAnswerService.save(answer);
    }

    @DeleteMapping("/{id}")
    public void deleteById(@PathVariable Long id) {
        textAnswerService.deleteById(id);
    }
}