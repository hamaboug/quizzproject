package com.quiz.back.controllers;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.quiz.back.models.MultipleChoiceQuestion;
import com.quiz.back.models.Option;
import com.quiz.back.models.Question;
import com.quiz.back.models.Quiz;
import com.quiz.back.models.QuizDTO;
import com.quiz.back.models.TextQuestion;
import com.quiz.back.services.MultipleChoiceQuestionService;
import com.quiz.back.services.OptionService;
import com.quiz.back.services.QuizService;
import com.quiz.back.services.TextQuestionService;

@RestController
@RequestMapping("/quizzes")
public class QuizController {
    
    @Autowired
    private QuizService quizService;

    @Autowired
    private OptionService optionService;

    @Autowired
    private MultipleChoiceQuestionService multipleChoiceQuestionService;

    @Autowired
    private TextQuestionService textQuestionService;

    @GetMapping
    public List<Quiz> findAll() {
        return quizService.findAll();
    }

    @GetMapping("/{id}")
    public Optional<Quiz> findById(@PathVariable Long id) {
        return quizService.findById(id);
    }

    @PostMapping
    public Quiz save(@RequestBody QuizDTO quizDTO) {
        Quiz quiz = new Quiz();
        quiz.setTitle(quizDTO.getTitle());
        quiz.setDescription(quizDTO.getDescription());

        Set<Question> questions = new HashSet<>();


        if(quizDTO.getMultipleChoiceQuestions()!=null)
        for(int i = 0; i < quizDTO.getMultipleChoiceQuestions().size(); i++) {
            MultipleChoiceQuestion multipleChoiceQuestion = new MultipleChoiceQuestion();
            multipleChoiceQuestion.setEnonce(quizDTO.getMultipleChoiceQuestions().get(i).getEnonce());
            multipleChoiceQuestion.setQuiz(quiz);

            List<Option> options = new ArrayList<>();

            for(int j = 0; j < quizDTO.getMultipleChoiceQuestions().get(i).getOptions().size(); j++) {
                Option option = new Option();
                option.setText(quizDTO.getMultipleChoiceQuestions().get(i).getOptions().get(j).getText());
                option.setIsCorrect(quizDTO.getMultipleChoiceQuestions().get(i).getOptions().get(j).isCorrect());
                option.setQuestion(multipleChoiceQuestion);
                options.add(option);
            }
            multipleChoiceQuestion.setOptions(options);

            questions.add(multipleChoiceQuestion);
        
        }


        if(quizDTO.getTextQuestions()!=null)
        for(int i = 0; i < quizDTO.getTextQuestions().size(); i++) {
            TextQuestion textQuestion = new TextQuestion();
            textQuestion.setEnonce(quizDTO.getTextQuestions().get(i).getEnonce());
            textQuestion.setQuiz(quiz);
            textQuestion.setExpectedAnswer(quizDTO.getTextQuestions().get(i).getExpectedAnswer());
            questions.add(textQuestion);
        }

        quiz.setQuestions(questions);

        return   quizService.save(quiz);
        

    }

    @DeleteMapping("/{id}")
    public void deleteById(@PathVariable Long id) {
        quizService.deleteById(id);
    }
}
