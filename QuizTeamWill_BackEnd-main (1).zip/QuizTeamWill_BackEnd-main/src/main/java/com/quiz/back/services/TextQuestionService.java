package com.quiz.back.services;


import com.quiz.back.models.TextQuestion;
import com.quiz.back.repositories.TextQuestionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class TextQuestionService {

    @Autowired
    private TextQuestionRepository textQuestionRepository;

    public List<TextQuestion> findAll() {
        return textQuestionRepository.findAll();
    }

    public Optional<TextQuestion> findById(Long id) {
        return textQuestionRepository.findById(id);
    }

    public TextQuestion save(TextQuestion TextQuestion) {
        return textQuestionRepository.save(TextQuestion);
    }

    public void deleteById(Long id) {
        textQuestionRepository.deleteById(id);
    }
}