package com.quiz.back.models;

import lombok.Data;

@Data
public class TextAnswerDTO extends AnswerDTO {
    private String answerText;
    private boolean isCorrect;

  

}
