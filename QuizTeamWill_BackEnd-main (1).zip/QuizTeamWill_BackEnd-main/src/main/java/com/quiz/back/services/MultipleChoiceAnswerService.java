package com.quiz.back.services;

import com.quiz.back.models.MultipleChoiceAnswer;
import com.quiz.back.repositories.MultipleChoiceAnswerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class MultipleChoiceAnswerService {
    @Autowired
    private MultipleChoiceAnswerRepository multipleChoiceAnswerRepository;

    public List<MultipleChoiceAnswer> findAll() {
        return multipleChoiceAnswerRepository.findAll();
    }

    public Optional<MultipleChoiceAnswer> findById(Long id) {
        return multipleChoiceAnswerRepository.findById(id);
    }

    public MultipleChoiceAnswer save(MultipleChoiceAnswer answer) {
        return multipleChoiceAnswerRepository.save(answer);
    }

    public void deleteById(Long id) {
        multipleChoiceAnswerRepository.deleteById(id);
    }
}