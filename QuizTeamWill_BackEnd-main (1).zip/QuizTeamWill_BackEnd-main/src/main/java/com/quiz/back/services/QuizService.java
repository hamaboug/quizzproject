package com.quiz.back.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.quiz.back.models.MultipleChoiceQuestion;
import com.quiz.back.models.Quiz;
import com.quiz.back.repositories.OptionRepository;
import com.quiz.back.repositories.QuestionRepository;
import com.quiz.back.repositories.QuizRepository;

@Service
public class QuizService {
    

      @Autowired
    private QuizRepository quizRepository;

    @Autowired
    private QuestionRepository questionRepository;

    @Autowired
    private OptionRepository optionRepository;
    

    public  List<Quiz> findAll() {
        return new ArrayList<>(quizRepository.findAll());
    }

    public  Optional<Quiz> findById(Long id) {
        return quizRepository.findById(id);
    }

    public Quiz save(Quiz quiz) {
        // Set up all relationships before saving
        if (quiz.getQuestions() != null) {
            quiz.getQuestions().forEach(question -> {
                question.setQuiz(quiz);
                
                if (question instanceof MultipleChoiceQuestion) {
                    MultipleChoiceQuestion mcq = (MultipleChoiceQuestion) question;
                    mcq.getOptions().forEach(option -> {
                        option.setQuestion(mcq);
                    });
                }
            });
        }
        
        // Single save operation with cascading
        return quizRepository.save(quiz);
    }

    public void deleteById(Long id) {
        quizRepository.deleteById(id);
    }
    
}
