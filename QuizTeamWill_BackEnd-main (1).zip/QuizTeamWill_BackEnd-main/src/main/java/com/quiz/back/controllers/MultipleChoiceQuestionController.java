package com.quiz.back.controllers;

import com.quiz.back.models.MultipleChoiceQuestion;
import com.quiz.back.services.MultipleChoiceQuestionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/multiplechoicequestions")
public class MultipleChoiceQuestionController {

    @Autowired
    private MultipleChoiceQuestionService multipleChoiceQuestionService;

    @GetMapping
    public List<MultipleChoiceQuestion> findAll() {
        return multipleChoiceQuestionService.findAll();
    }

    @GetMapping("/{id}")
    public Optional<MultipleChoiceQuestion> findById(@PathVariable Long id) {
        return multipleChoiceQuestionService.findById(id);
    }

    @PostMapping
    public MultipleChoiceQuestion save(@RequestBody MultipleChoiceQuestion MultipleChoiceQuestion) {
        return multipleChoiceQuestionService.save(MultipleChoiceQuestion);
    }

    @DeleteMapping("/{id}")
    public void deleteById(@PathVariable Long id) {
        multipleChoiceQuestionService.deleteById(id);
    }
}