package com.quiz.back.models;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import jakarta.persistence.*;

import lombok.Data;

@Entity
@Data
@DiscriminatorValue("multiple_choice_answer")
public class MultipleChoiceAnswer extends Answer {

   public MultipleChoiceAnswer() {
        super();
    }

    @ManyToMany
    @JoinTable(
        name = "mca_options",
        joinColumns = @JoinColumn(name = "answer_id"),
        inverseJoinColumns = @JoinColumn(name = "option_id")
    )
    private Set<Option> selectedOptions = new HashSet<>();

}
