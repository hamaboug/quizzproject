package com.quiz.back.models;

import java.util.List;

import lombok.Data;

@Data
public class ResultDTO {
    private Long userId;
    private Long quizId;
    private List<AnswerDTO> answers;
    private float timeInMinutes;
}
