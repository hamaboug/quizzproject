package com.quiz.back.services;


import com.quiz.back.models.Question;
import com.quiz.back.repositories.QuestionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class QuestionService {

    @Autowired
    private QuestionRepository questionRepository;

    public List<Question> findAll() {
        return questionRepository.findAll();
    }

    public Optional<Question> findById(Long id) {
        return questionRepository.findById(id);
    }

    public Question save(Question Question) {
        return questionRepository.save(Question);
    }

    public void deleteById(Long id) {
        questionRepository.deleteById(id);
    }
}