package com.quiz.back.services;

import com.quiz.back.models.Option;
import com.quiz.back.repositories.OptionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

@Service
public class OptionService {

    @Autowired
    private OptionRepository optionRepository;

    public List<Option> findAll() {
        return optionRepository.findAll();
    }

    public Optional<Option> findById(Long id) {
        return optionRepository.findById(id);
    }

    public Option save(Option option) {
        return optionRepository.save(option);
    }

    public void deleteById(Long id) {
        optionRepository.deleteById(id);
    }

    public Set<Option> findAllById(Collection<Long> ids) {
        return new HashSet<>(optionRepository.findAllByIdIn(ids));
    }
}