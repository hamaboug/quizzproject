package com.quiz.back.controllers;
import com.quiz.back.models.TextQuestion;
import com.quiz.back.services.TextQuestionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/textquestions")
public class TextQuestionController {

    @Autowired
    private TextQuestionService textQuestionService;

    @GetMapping
    public List<TextQuestion> findAll() {
        return textQuestionService.findAll();
    }

    @GetMapping("/{id}")
    public Optional<TextQuestion> findById(@PathVariable Long id) {
        return textQuestionService.findById(id);
    }

    @PostMapping
    public TextQuestion save(@RequestBody TextQuestion TextQuestion) {
        return textQuestionService.save(TextQuestion);
    }

    @DeleteMapping("/{id}")
    public void deleteById(@PathVariable Long id) {
        textQuestionService.deleteById(id);
    }
}