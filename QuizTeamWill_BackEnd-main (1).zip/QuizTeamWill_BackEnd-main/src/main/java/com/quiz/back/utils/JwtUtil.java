package com.quiz.back.utils;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.security.Keys;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;

import com.quiz.back.models.User;

import java.security.Key;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;

@Component
public class JwtUtil {
    private static final Key SECRET_KEY = Keys.hmacShaKeyFor("ca88fa1e1cf84824b632b6a442832d716dabfaa4b5da7c25f49c4a12ce96b2d61a741052dbc788bb961c27fd63e0a7814f0aa15ed5318049f8d2d497328de5b2ddc766967f7bbbe1f6d7e42dd473a8b1f01d1055a65c44981dc7c980f2002c0fc3b1a29a614c25440164c360f0ad6230e7e70ec0b6f761767a3039441c126114e32cb55317289af4ae30446291d37e822a6b9f161fb404e57312469d536ebed64ba95c207b2caf91f95912103f65db88790437ab5095c37fe891c31d4c5f8c9315d94d5c26181f18c6a0cd3ca7177b2f81837220d2372cf962167e3218bcd492ab913984e4bb4474248d03c3c835c82e7d40e414fe71324a1547f083c8c7c5fd7b".getBytes());
    private static final long EXPIRATION_TIME = 21600000;

    public String generateToken(User user) {
        Map<String, Object> claims = new HashMap<>();
        claims.put("id", user.getId());
        System.out.println(user.getEmail());
        if(user.getEmail().equals("malek.2002@teamwillgroup.com")) {
            System.out.println("admin");
            claims.put("role", "admin");
        } else {
        claims.put("role", "user");
        }

        return createToken(claims, user.getEmail());
    }

    public String createToken(Map<String, Object> claims, String subject) {
        return Jwts.builder()
                .setClaims(claims)
                .setSubject(subject)
                .setIssuedAt(new Date(System.currentTimeMillis()))
                .setExpiration(new Date(System.currentTimeMillis() + EXPIRATION_TIME))
                .signWith(SECRET_KEY)
                .compact();
    }

    public String extractEmail(String token) {
        return extractClaim(token, Claims::getSubject);
    }

    public <T> T extractClaim(String token, Function<Claims, T> claimsResolver) {
        final Claims claims = extractAllClaims(token);
        return claimsResolver.apply(claims);
    }

    private Claims extractAllClaims(String token) {
        return Jwts.parserBuilder().setSigningKey(SECRET_KEY).build().parseClaimsJws(token).getBody();
    }

    public Boolean validateToken(String token, UserDetails userDetails) {
        final String email = extractEmail(token);
        return (email.equals(userDetails.getUsername()) && !isTokenExpired(token));
    }

    private Boolean isTokenExpired(String token) {
        return extractExpiration(token).before(new Date());
    }

    private Date extractExpiration(String token) {
        return extractClaim(token, Claims::getExpiration);
    }
}