package com.quiz.back.controllers;

import com.quiz.back.models.Option;
import com.quiz.back.services.OptionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/options")
public class OptionController {

    @Autowired
    private OptionService optionService;

    @GetMapping
    public List<Option> findAll() {
        return optionService.findAll();
    }

    @GetMapping("/{id}")
    public Optional<Option> findById(@PathVariable Long id) {
        return optionService.findById(id);
    }

    @PostMapping
    public Option save(@RequestBody Option Option) {
        return optionService.save(Option);
    }

    @DeleteMapping("/{id}")
    public void deleteById(@PathVariable Long id) {
        optionService.deleteById(id);
    }
}