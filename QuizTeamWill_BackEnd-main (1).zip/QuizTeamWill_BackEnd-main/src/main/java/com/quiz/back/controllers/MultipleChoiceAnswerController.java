package com.quiz.back.controllers;

import com.quiz.back.models.MultipleChoiceAnswer;
import com.quiz.back.services.MultipleChoiceAnswerService;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/multiple-choice-answers")
public class MultipleChoiceAnswerController {
    @Autowired
    private MultipleChoiceAnswerService multipleChoiceAnswerService;

    @GetMapping
    public List<MultipleChoiceAnswer> findAll() {
        return multipleChoiceAnswerService.findAll();
    }

    @GetMapping("/{id}")
    public Optional<MultipleChoiceAnswer> findById(@PathVariable Long id) {
        return multipleChoiceAnswerService.findById(id);
    }

    @PostMapping
    public MultipleChoiceAnswer save(@RequestBody MultipleChoiceAnswer answer) {
        return multipleChoiceAnswerService.save(answer);
    }

    @DeleteMapping("/{id}")
    public void deleteById(@PathVariable Long id) {
        multipleChoiceAnswerService.deleteById(id);
    }
}