package com.quiz.back.services;

import com.quiz.back.models.Answer;
import com.quiz.back.repositories.AnswerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class AnswerService {

    @Autowired
    private AnswerRepository answerRepository;

    public List<Answer> findAll() {
        return answerRepository.findAll();
    }

    public Optional<Answer> findById(Long id) {
        return answerRepository.findById(id);
    }

    public Answer save(Answer Answer) {
        return answerRepository.save(Answer);
    }

    public void deleteById(Long id) {
        answerRepository.deleteById(id);
    }
}