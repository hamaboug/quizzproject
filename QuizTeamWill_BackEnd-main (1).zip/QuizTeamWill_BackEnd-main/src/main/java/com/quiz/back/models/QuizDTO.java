package com.quiz.back.models;

import java.util.List;

import lombok.Data;


@Data
public class QuizDTO {
    private String title;
    private String description;
    private List<MultipleChoiceQuestionDTO> multipleChoiceQuestions;
    private List<TextQuestionDTO> textQuestions;
}
