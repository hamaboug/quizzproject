package com.quiz.back.models;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Entity
@AllArgsConstructor
@NoArgsConstructor
@Data
@Table(name="question")
@Inheritance(strategy = InheritanceType.SINGLE_TABLE) // All subclasses share the same table
@DiscriminatorColumn(name = "type", discriminatorType = DiscriminatorType.STRING) // Discriminator column
public class Question {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    protected Long id;

    @ManyToOne
    @JoinColumn(name = "quiz", nullable = false)
    @JsonBackReference
    private Quiz quiz;

    @Column(name="enonce", nullable = false)
    private String Enonce;


}
