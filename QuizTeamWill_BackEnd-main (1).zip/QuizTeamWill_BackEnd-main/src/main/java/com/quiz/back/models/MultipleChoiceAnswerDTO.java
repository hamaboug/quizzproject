package com.quiz.back.models;

import java.util.List;

import lombok.Data;

@Data
public class MultipleChoiceAnswerDTO extends AnswerDTO {
    private List<Long> selectedOptionIds;
    private boolean isCorrect;

  

    // Getters and setters
}