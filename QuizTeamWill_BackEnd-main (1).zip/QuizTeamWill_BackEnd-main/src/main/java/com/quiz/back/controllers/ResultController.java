package com.quiz.back.controllers;

import com.quiz.back.models.Answer;
import com.quiz.back.models.AnswerDTO;
import com.quiz.back.models.MultipleChoiceAnswer;
import com.quiz.back.models.MultipleChoiceAnswerDTO;
import com.quiz.back.models.MultipleChoiceQuestion;
import com.quiz.back.models.Option;
import com.quiz.back.models.Quiz;
import com.quiz.back.models.Result;
import com.quiz.back.models.ResultDTO;
import com.quiz.back.models.TextAnswer;
import com.quiz.back.models.TextAnswerDTO;
import com.quiz.back.models.TextQuestion;
import com.quiz.back.models.User;
import com.quiz.back.services.OptionService;
import com.quiz.back.services.QuestionService;
import com.quiz.back.services.QuizService;
import com.quiz.back.services.ResultService;
import com.quiz.back.services.UserService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;


@RestController
@RequestMapping("/results")
public class ResultController {
    @Autowired
    private ResultService resultService;

    @Autowired
    private UserService userService;

    @Autowired
    private QuizService quizService;

    @Autowired
    private QuestionService questionService;

    @Autowired
    private OptionService optionService;

    @GetMapping
    public List<Result> findAll() {
        return resultService.findAll();
    }

    @GetMapping("/{id}")
    public Optional<Result> findById(@PathVariable Long id) {
        return resultService.findById(id);
    }

    @GetMapping("/user/{userId}")
    public List<Result> findByUserId(@PathVariable Long userId) {
    return resultService.findByUserId(userId);
    }

    @PostMapping
    public Result save(@RequestBody Result result) {
        return resultService.save(result);
    }

    @DeleteMapping("/{id}")
    public void deleteById(@PathVariable Long id) {
        resultService.deleteById(id);
    }


    @PostMapping("/submit")
public Result submitResult(@RequestBody ResultDTO submission) {
    Result result = new Result();  

    result.setTimeInMinutes(submission.getTimeInMinutes());
    
    User user = userService.findById(submission.getUserId())
        .orElseThrow(() -> new RuntimeException("User not found"));
    Quiz quiz = quizService.findById(submission.getQuizId())
        .orElseThrow(() -> new RuntimeException("Quiz not found"));

    result.setUser(user);
    result.setQuiz(quiz);

    List<Answer> answers = new ArrayList<>();
    double score = 0;

    for (AnswerDTO answerDTO : submission.getAnswers()) {
        if (answerDTO instanceof MultipleChoiceAnswerDTO) {
            MultipleChoiceAnswerDTO mcaDTO = (MultipleChoiceAnswerDTO) answerDTO;
            MultipleChoiceAnswer mca = new MultipleChoiceAnswer();
            
            MultipleChoiceQuestion question = (MultipleChoiceQuestion) questionService
                .findById(mcaDTO.getQuestionId())
                .orElseThrow(() -> new RuntimeException("Question not found"));
            
            mca.setQuestion(question);
            mca.setUser(user);
            mca.setResult(result);  // Use the correct Result instance

            Set<Option> selectedOptions = optionService.findAllById(mcaDTO.getSelectedOptionIds());
            mca.setSelectedOptions(selectedOptions);
            
            boolean isCorrect = validateMultipleChoiceAnswer(question, selectedOptions);
            if (isCorrect) score++;

            answers.add(mca);
        } else if (answerDTO instanceof TextAnswerDTO) {
            TextAnswerDTO taDTO = (TextAnswerDTO) answerDTO;
            TextAnswer ta = new TextAnswer();

            TextQuestion question = (TextQuestion) questionService
                .findById(taDTO.getQuestionId())
                .orElseThrow(() -> new RuntimeException("Question not found"));
            
            ta.setQuestion(question);
            ta.setUser(user);
            ta.setResult(result);  // Use the correct Result instance
            ta.setText(taDTO.getAnswerText());

            boolean isCorrect = validateTextAnswer(question, taDTO.getAnswerText());
            if (isCorrect) score++;

            answers.add(ta);
        }
    }

    double finalScore = (score / submission.getAnswers().size()) * 100;
    result.setAnswers(answers);
    result.setScore(finalScore);

    return resultService.save(result);
}


private boolean validateMultipleChoiceAnswer(MultipleChoiceQuestion question, Set<Option> selectedOptions) {
    Set<Option> correctOptions = question.getOptions().stream()
        .filter(Option::isCorrect)
        .collect(Collectors.toSet());
    return correctOptions.equals(selectedOptions);
}

private boolean validateTextAnswer(TextQuestion question, String answer) {
    return question.getExpectedAnswer().equalsIgnoreCase(answer.trim());
}

    
}