package com.quiz.back.models;

import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;

@Entity
@DiscriminatorValue("text_answer")
public class TextAnswer extends Answer {
    private String text;

    public TextAnswer() {
        super();
    }

    public TextAnswer(String text) {
        this.text = text;
    }

    public String getText() {
        return this.text;
    }

    public void setText(String text) {
        this.text = text;
    }
    
}
