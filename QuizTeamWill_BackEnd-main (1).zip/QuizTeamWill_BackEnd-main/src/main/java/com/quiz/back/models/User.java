package com.quiz.back.models;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name = "users")
@Data
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true)
    private String email;

    @Column(nullable = false)
    private String password;
   
   
    // @OneToMany(mappedBy = "user", cascade = CascadeType.ALL)
    // @JsonManagedReference
    // private List<Result> results = new ArrayList<>();

}