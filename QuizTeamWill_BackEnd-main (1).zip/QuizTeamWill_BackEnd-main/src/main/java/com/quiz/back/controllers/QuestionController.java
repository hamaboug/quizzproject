package com.quiz.back.controllers;


import com.quiz.back.models.Question;
import com.quiz.back.services.QuestionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/questions")
public class QuestionController {

    @Autowired
    private QuestionService questionService;

    @GetMapping
    public List<Question> findAll() {
        return questionService.findAll();
    }

    @GetMapping("/{id}")
    public Optional<Question> findById(@PathVariable Long id) {
        return questionService.findById(id);
    }

    @PostMapping
    public Question save(@RequestBody Question Question) {
        return questionService.save(Question);
    }

    @DeleteMapping("/{id}")
    public void deleteById(@PathVariable Long id) {
        questionService.deleteById(id);
    }
}
